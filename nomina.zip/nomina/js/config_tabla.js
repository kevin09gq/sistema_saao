// Paginación simple para nómina 
let empleadosPaginados = [];
let paginaActualNomina = 1;
const empleadosPorPagina = 7;

// Cache de colores por clave de empleado para no repetir solicitudes
window.colorPuestoCache = window.colorPuestoCache || {};

function obtenerColorPuestoPorClave(clave, callback) {
    if (!clave) return callback && callback(null);
    const k = String(clave);
    if (window.colorPuestoCache.hasOwnProperty(k)) {
        return callback && callback(window.colorPuestoCache[k]);
    }
    $.ajax({
        type: 'POST',
        url: '../php/obtener_color_puesto.php',
        data: JSON.stringify({ clave: k }),
        contentType: 'application/json',
        success: function (resp) {
            try {
                const data = (typeof resp === 'string') ? JSON.parse(resp) : resp;
                const color = (data && data.success) ? (data.color_hex || null) : null;
                window.colorPuestoCache[k] = color;
                if (callback) callback(color);
            } catch (e) {
                window.colorPuestoCache[k] = null;
                if (callback) callback(null);
            }
        },
        error: function () {
            window.colorPuestoCache[k] = null;
            if (callback) callback(null);
        }
    });
}

function aplicarColoresPuestosEnTabla(tbodySelector) {
    const $tbody = $(tbodySelector);
    $tbody.find('tr').each(function () {
        const $tr = $(this);
        const clave = $tr.attr('data-clave');
        const $tdNombre = $tr.find('td').eq(1);
        if (!$tdNombre.length) return;
        obtenerColorPuestoPorClave(clave, function (color) {
            if (color && /^#[0-9A-Fa-f]{6}$/.test(color)) {
                $tdNombre.css('color', color);
            } else {
                $tdNombre.css('color', ''); // negro por defecto via CSS
            }
        });
    });
}

function setEmpleadosPaginados(array) {
    // Recalcular sueldos antes de filtrar
    array.forEach(emp => {
        if (typeof calcularSueldoACobraPorEmpleado === 'function') {
            calcularSueldoACobraPorEmpleado(emp);
        }
    });
    
    // Filtrar solo empleados registrados antes de paginar
    filtrarEmpleadosRegistradosYPaginar(array);
}

// Nueva función para filtrar empleados registrados antes de la paginación
function filtrarEmpleadosRegistradosYPaginar(todosLosEmpleados) {
    // Obtener claves de empleados registrados
    let claves = obtenerClavesEmpleados();
    
    // Enviar petición AJAX para validar claves
    $.ajax({
        type: "POST",
        url: "../php/validar_clave.php",
        data: JSON.stringify({ claves: claves }),
        contentType: "application/json",
        success: function (clavesValidasJSON) {
            const clavesValidas = JSON.parse(clavesValidasJSON);
            
            // Filtrar solo empleados que están registrados en la base de datos
            const empleadosRegistrados = todosLosEmpleados.filter(emp => {
                return clavesValidas.includes(String(emp.clave)) || clavesValidas.includes(Number(emp.clave));
            });
            
            // Recalcular sueldos antes de asignar
            empleadosRegistrados.forEach(emp => {
                if (typeof calcularSueldoACobraPorEmpleado === 'function') {
                    calcularSueldoACobraPorEmpleado(emp);
                }
            });
            
            // Ahora asignar a empleadosPaginados solo los empleados registrados
            empleadosPaginados = empleadosRegistrados;
            paginaActualNomina = 1;
            
            // Actualizar empleados filtrados globales
            actualizarEmpleadosFiltradosGlobales();
            
            renderTablaPaginada();
        },
        error: function(xhr, status, error) {
          
            // En caso de error, usar todos los empleados
            empleadosPaginados = todosLosEmpleados;
            paginaActualNomina = 1;
            renderTablaPaginada();
        }
    });
}

function renderTablaPaginada() {
    const inicio = (paginaActualNomina - 1) * empleadosPorPagina;
    const fin = inicio + empleadosPorPagina;
    // Tomar la página actual y sincronizar con empleadosOriginales para valores más recientes
    let empleadosPagina = empleadosPaginados.slice(inicio, fin).map(emp => {
        const actualizado = (window.empleadosOriginales || []).find(e => String(e.clave) === String(emp.clave));
        return actualizado ? actualizado : emp;
    });
    
    // Recalcular sueldos antes de renderizar
    empleadosPagina.forEach(emp => {
        if (typeof calcularSueldoACobraPorEmpleado === 'function') {
            calcularSueldoACobraPorEmpleado(emp);
        }
    });
    
    // Renderiza la tabla con los empleados de la página actual
    mostrarDatosTablaPaginada(empleadosPagina);
    renderPaginacionNomina();
}

// Función para obtener las claves de empleados del departamento "PRODUCCION 40 LIBRAS"
function obtenerClavesEmpleados() {
    let claves = [];
    const seleccionado = ($('#departamentos-nomina').val() || '').toUpperCase();
    if (jsonGlobal && jsonGlobal.departamentos) {
        jsonGlobal.departamentos.forEach(depto => {
            const nombreDepto = (depto.nombre || '').toUpperCase();
            if (seleccionado && nombreDepto.includes(seleccionado)) {
                (depto.empleados || []).forEach(emp => {
                    if (emp.clave) {
                        claves.push(emp.clave);
                    }
                });
            }
        });
    }

    return claves;
}

// Función para mostrar datos de la tabla con paginación
function mostrarDatosTablaPaginada(empleadosPagina) {
    // Limpiar la tabla
    $('#tabla-nomina-body').empty();
    
    // Calcular el número de fila inicial para la página actual
    let numeroFila = ((paginaActualNomina - 1) * empleadosPorPagina) + 1;
    
    // Asegurar que la lista venga sincronizada con empleadosOriginales por si fue llamada directamente
    empleadosPagina = empleadosPagina.map(emp => {
        const actualizado = (window.empleadosOriginales || []).find(e => String(e.clave) === String(emp.clave));
        return actualizado ? actualizado : emp;
    });

    // Renderizar solo los empleados de la página actual
    // Helper para mostrar deducciones con signo "-"
    const mostrarDeduccion = (valor) => {
        if (valor === 0 || valor === '0' || valor === '' || valor === null || valor === undefined || isNaN(valor)) {
            return '';
        }
        const num = parseFloat(valor);
        return isNaN(num) ? '' : `-${num.toFixed(2)}`;
    };
    // Nota: empleadosPagina ya contiene solo empleados registrados
    empleadosPagina.forEach(emp => {
        // Recalcular sueldo a cobrar antes de mostrar
        if (typeof calcularSueldoACobraPorEmpleado === 'function') {
            calcularSueldoACobraPorEmpleado(emp);
        }
        
        // Obtener conceptos
        const conceptos = emp.conceptos || [];
        const getConcepto = (codigo) => {
            const c = conceptos.find(c => c.codigo === codigo);
            return c ? parseFloat(c.resultado).toFixed(2) : '';
        };
        const infonavit = getConcepto('16');
        const isr = getConcepto('45');
        const imss = getConcepto('52');

        // Usar el puesto original del empleado
        let puestoEmpleado = emp.puesto || emp.nombre_departamento || '';

        // Obtener el incentivo si existe y formatearlo correctamente
        const incentivo = emp.incentivo ? parseFloat(emp.incentivo).toFixed(2) : '';

        // Función para mostrar cadena vacía en lugar de 0, NaN o valores vacíos
        const mostrarValor = (valor) => {
            if (valor === 0 || valor === '0' || valor === '' || valor === null || valor === undefined || isNaN(valor)) {
                return '';
            }
            // Formatear números con dos decimales
            const num = parseFloat(valor);
            return isNaN(num) ? '' : num.toFixed(2);
        };

        const claseSueldo = (parseFloat(emp.sueldo_a_cobrar) || 0) < 0 ? 'sueldo-negativo' : 'sueldo-final';
        let fila = `
            <tr data-clave="${emp.clave}">
                <td>${numeroFila++}</td>
                <td>${emp.nombre}</td>
                <td>${puestoEmpleado}</td>
                <td>${mostrarValor(emp.sueldo_base)}</td>
                <td>${mostrarValor(incentivo)}</td>
                <td>${mostrarValor(emp.sueldo_extra_final)}</td>
                <td>${mostrarDeduccion(emp.neto_pagar)}</td>
                <td>${mostrarDeduccion(emp.prestamo)}</td>
                <td>${mostrarDeduccion(emp.inasistencias_descuento)}</td>
                <td>${mostrarDeduccion(emp.uniformes)}</td>
                <td>${mostrarDeduccion(infonavit)}</td>
                <td>${mostrarDeduccion(isr)}</td>
                <td>${mostrarDeduccion(imss)}</td>
                <td>${mostrarDeduccion(emp.checador)}</td>
                <td>${mostrarDeduccion(emp.fa_gafet_cofia)}</td>
                <td class="${claseSueldo}">${mostrarValor(emp.sueldo_a_cobrar)}</td>
            </tr>
        `;
        $('#tabla-nomina-body').append(fila);
    });
    
    // Re-inicializar el menú contextual después de renderizar la tabla
    inicializarMenuContextual();
    // Aplicar colores de puestos
    aplicarColoresPuestosEnTabla('#tabla-nomina-body');
}

// Función para actualizar empleados filtrados globales cuando se cambie el set paginado
function actualizarEmpleadosFiltradosGlobales() {
    if (window.empleadosFiltrados) {
        window.empleadosFiltrados = [...empleadosPaginados];
    }
}

// ========================================
// PAGINACIÓN PARA TABLA PRINCIPAL
// ========================================

function renderPaginacionNomina() {
    const totalPaginas = Math.ceil(empleadosPaginados.length / empleadosPorPagina);
    let html = '';
    
    if (totalPaginas > 1) {
        // Botón anterior
        html += `<li class="page-item${paginaActualNomina === 1 ? ' disabled' : ''}">
            <a class="page-link" href="#" onclick="cambiarPaginaNomina(${paginaActualNomina - 1}); return false;">&laquo;</a>
        </li>`;
        
        // Determinar qué números de página mostrar
        const paginasVisibles = 5; // Número de páginas a mostrar además de la primera y última
        const paginas = [];
        
        // Siempre agregar la primera página
        paginas.push(1);
        
        // Calcular el rango alrededor de la página actual
        const inicio = Math.max(2, paginaActualNomina - Math.floor(paginasVisibles/2));
        const fin = Math.min(totalPaginas - 1, inicio + paginasVisibles - 1);
        
        // Agregar ellipsis después de la página 1 si es necesario
        if (inicio > 2) {
            paginas.push('...');
        }
        
        // Agregar páginas del rango calculado
        for (let i = inicio; i <= fin; i++) {
            paginas.push(i);
        }
        
        // Agregar ellipsis antes de la última página si es necesario
        if (fin < totalPaginas - 1) {
            paginas.push('...');
        }
        
        // Siempre agregar la última página si hay más de una página
        if (totalPaginas > 1) {
            paginas.push(totalPaginas);
        }
        
        // Generar HTML para cada número de página o ellipsis
        paginas.forEach(pagina => {
            if (pagina === '...') {
                html += `<li class="page-item disabled"><a class="page-link" href="#">...</a></li>`;
            } else {
                html += `<li class="page-item${paginaActualNomina === pagina ? ' active' : ''}">
                    <a class="page-link" href="#" onclick="cambiarPaginaNomina(${pagina}); return false;">${pagina}</a>
                </li>`;
            }
        });
        
        // Botón siguiente
        html += `<li class="page-item${paginaActualNomina === totalPaginas ? ' disabled' : ''}">
            <a class="page-link" href="#" onclick="cambiarPaginaNomina(${paginaActualNomina + 1}); return false;">&raquo;</a>
        </li>`;
    }
    
    $("#paginacion-nomina").html(html);
}

function cambiarPaginaNomina(nuevaPagina) {
    const totalPaginas = Math.ceil(empleadosPaginados.length / empleadosPorPagina);
    if (nuevaPagina < 1 || nuevaPagina > totalPaginas) return;
    paginaActualNomina = nuevaPagina;
    renderTablaPaginada();
}

// Función para mantener compatibilidad con el código existente
function mostrarDatosTabla() {
    // Si se llama desde el código existente, usar la paginación
    if (empleadosPaginados.length > 0) {
        renderTablaPaginada();
    } else {
        // Fallback: mostrar todos los datos sin paginación
     
        if (window.empleadosOriginales && window.empleadosOriginales.length > 0) {
            setEmpleadosPaginados(window.empleadosOriginales);
        }
    }
}

// ========================================
// PAGINACIÓN PARA TABLA DE DISPERSIÓN
// ========================================

// Variables para paginación de dispersión
let empleadosDispersionPaginados = [];
let paginaActualDispersion = 1;
const empleadosPorPaginaDispersion = 7;

// Función para establecer empleados paginados para dispersión
function setEmpleadosDispersionPaginados(array, mantenerPagina = false) {
    // Recalcular sueldos antes de asignar
    array.forEach(emp => {
        if (typeof calcularSueldoACobraPorEmpleado === 'function') {
            calcularSueldoACobraPorEmpleado(emp);
        }
    });
    
    empleadosDispersionPaginados = array;
    
    // Solo reiniciar a la página 1 si no se debe mantener la página actual
    if (!mantenerPagina) {
        paginaActualDispersion = 1;
    }
    
    renderTablaDispersionPaginada();
}

// Función para renderizar tabla de dispersión paginada
function renderTablaDispersionPaginada() {
    const inicio = (paginaActualDispersion - 1) * empleadosPorPaginaDispersion;
    const fin = inicio + empleadosPorPaginaDispersion;
    const empleadosPagina = empleadosDispersionPaginados.slice(inicio, fin);
    
    // Recalcular sueldos antes de renderizar
    empleadosPagina.forEach(emp => {
        if (typeof calcularSueldoACobraPorEmpleado === 'function') {
            calcularSueldoACobraPorEmpleado(emp);
        }
    });
    
    // Renderiza la tabla con los empleados de la página actual
    mostrarDatosTablaDispersionPaginada(empleadosPagina);
    renderPaginacionDispersion();
}

// Función para mostrar datos de la tabla de dispersión con paginación
function mostrarDatosTablaDispersionPaginada(empleadosPagina) {
    // Limpiar la tabla
    $('#tabla-dispersion-body').empty();
    
    let numeroFila = ((paginaActualDispersion - 1) * empleadosPorPaginaDispersion) + 1;
    
    // Función para mostrar cadena vacía en lugar de 0, NaN o valores vacíos
    const mostrarValor = (valor) => {
        if (valor === 0 || valor === '0' || valor === '' || valor === null || valor === undefined || isNaN(valor)) {
            return '';
        }
        // Formatear números con dos decimales
        const num = parseFloat(valor);
        return isNaN(num) ? '' : num.toFixed(2);
    };
    
    // Renderizar solo los empleados de la página actual
    empleadosPagina.forEach(emp => {
        if (emp && emp.clave && emp.nombre) {
            let fila = `
                <tr data-clave="${emp.clave}">
                    <td>${numeroFila++}</td>
                    <td>${emp.clave}</td>
                    <td>${emp.nombre}</td>
                    <td>${mostrarValor(emp.neto_pagar)}</td>
                </tr>
            `;
            $('#tabla-dispersion-body').append(fila);
        }
    });
}

// Función para renderizar paginación de dispersión
function renderPaginacionDispersion() {
    const totalPaginas = Math.ceil(empleadosDispersionPaginados.length / empleadosPorPaginaDispersion);
    let html = '';
    
    if (totalPaginas > 1) {
        // Botón anterior
        html += `<li class="page-item${paginaActualDispersion === 1 ? ' disabled' : ''}">
            <a class="page-link" href="#" onclick="cambiarPaginaDispersion(${paginaActualDispersion - 1}); return false;">&laquo;</a>
        </li>`;
        
        // Determinar qué números de página mostrar
        const paginasVisibles = 5; // Número de páginas a mostrar además de la primera y última
        const paginas = [];
        
        // Siempre agregar la primera página
        paginas.push(1);
        
        // Calcular el rango alrededor de la página actual
        const inicio = Math.max(2, paginaActualDispersion - Math.floor(paginasVisibles/2));
        const fin = Math.min(totalPaginas - 1, inicio + paginasVisibles - 1);
        
        // Agregar ellipsis después de la página 1 si es necesario
        if (inicio > 2) {
            paginas.push('...');
        }
        
        // Agregar páginas del rango calculado
        for (let i = inicio; i <= fin; i++) {
            paginas.push(i);
        }
        
        // Agregar ellipsis antes de la última página si es necesario
        if (fin < totalPaginas - 1) {
            paginas.push('...');
        }
        
        // Siempre agregar la última página si hay más de una página
        if (totalPaginas > 1) {
            paginas.push(totalPaginas);
        }
        
        // Generar HTML para cada número de página o ellipsis
        paginas.forEach(pagina => {
            if (pagina === '...') {
                html += `<li class="page-item disabled"><a class="page-link" href="#">...</a></li>`;
            } else {
                html += `<li class="page-item${paginaActualDispersion === pagina ? ' active' : ''}">
                    <a class="page-link" href="#" onclick="cambiarPaginaDispersion(${pagina}); return false;">${pagina}</a>
                </li>`;
            }
        });
        
        // Botón siguiente
        html += `<li class="page-item${paginaActualDispersion === totalPaginas ? ' disabled' : ''}">
            <a class="page-link" href="#" onclick="cambiarPaginaDispersion(${paginaActualDispersion + 1}); return false;">&raquo;</a>
        </li>`;
    }
    
    $("#paginacion-dispersion").html(html);
}

// Función para cambiar página en dispersión
function cambiarPaginaDispersion(nuevaPagina) {
    const totalPaginas = Math.ceil(empleadosDispersionPaginados.length / empleadosPorPaginaDispersion);
    if (nuevaPagina < 1 || nuevaPagina > totalPaginas) return;
    paginaActualDispersion = nuevaPagina;
    renderTablaDispersionPaginada();
}

// ========================================
// PAGINACIÓN PARA TABLA DE EMPLEADOS SIN SEGURO
// ========================================

let empleadosSinSeguroPaginados = [];
let paginaActualSinSeguro = 1;
const empleadosPorPaginaSinSeguro = 7;

// Función para establecer empleados paginados para empleados sin seguro
function setEmpleadosSinSeguroPaginados(array, mantenerPagina = false) {
    // Recalcular sueldos antes de asignar
    array.forEach(emp => {
        if (typeof calcularSueldoACobraPorEmpleado === 'function') {
            calcularSueldoACobraPorEmpleado(emp);
        }
    });
    
    empleadosSinSeguroPaginados = array;
    
    // Solo reiniciar a la página 1 si no se debe mantener la página actual
    if (!mantenerPagina) {
        paginaActualSinSeguro = 1;
    }
    
    renderTablaSinSeguroPaginada();
}

// Función para renderizar tabla de empleados sin seguro paginada
function renderTablaSinSeguroPaginada() {
    const inicio = (paginaActualSinSeguro - 1) * empleadosPorPaginaSinSeguro;
    const fin = inicio + empleadosPorPaginaSinSeguro;
    const empleadosPagina = empleadosSinSeguroPaginados.slice(inicio, fin);
    
    // Recalcular sueldos antes de renderizar
    empleadosPagina.forEach(emp => {
        if (typeof calcularSueldoACobraPorEmpleado === 'function') {
            calcularSueldoACobraPorEmpleado(emp);
        }
    });
    
    // Renderiza la tabla con los empleados de la página actual
    mostrarDatosTablaSinSeguroPaginada(empleadosPagina);
    renderPaginacionSinSeguro();
}

// Función para mostrar datos de la tabla de empleados sin seguro con paginación
function mostrarDatosTablaSinSeguroPaginada(empleadosPagina) {
    // Limpiar la tabla
    $('#tabla-sin-seguro-body').empty();
    
    // Calcular el número de fila inicial para la página actual
    let numeroFila = ((paginaActualSinSeguro - 1) * empleadosPorPaginaSinSeguro) + 1;
    
    // Renderizar solo los empleados de la página actual
    empleadosPagina.forEach(emp => {
        // Recalcular sueldo a cobrar antes de mostrar
        if (typeof calcularSueldoACobraPorEmpleado === 'function') {
            calcularSueldoACobraPorEmpleado(emp);
        }
        
        // Obtener conceptos
        const conceptos = emp.conceptos || [];
        const getConcepto = (codigo) => {
            const c = conceptos.find(c => c.codigo === codigo);
            return c ? parseFloat(c.resultado).toFixed(2) : '';
        };
        const infonavit = getConcepto('16');
        const isr = getConcepto('45');
        const imss = getConcepto('52');

        // Usar el puesto original del empleado
        let puestoEmpleado = emp.puesto || emp.nombre_departamento || '';

        // Obtener el incentivo si existe y formatearlo correctamente
        const incentivo = emp.incentivo ? parseFloat(emp.incentivo).toFixed(2) : '';

        // Función para mostrar cadena vacía en lugar de 0, NaN o valores vacíos
        const mostrarValor = (valor) => {
            if (valor === 0 || valor === '0' || valor === '' || valor === null || valor === undefined || isNaN(valor)) {
                return '';
            }
            // Formatear números con dos decimales
            const num = parseFloat(valor);
            return isNaN(num) ? '' : num.toFixed(2);
        };

        const claseSueldo = (parseFloat(emp.sueldo_a_cobrar) || 0) < 0 ? 'sueldo-negativo' : 'sueldo-final';
        let fila = `
            <tr data-clave="${emp.clave}">
                <td>${numeroFila++}</td>
                <td>${emp.nombre}</td>
                <td>${puestoEmpleado}</td>
                <td>${mostrarValor(emp.sueldo_base)}</td>
                <td>${mostrarValor(incentivo)}</td>
                <td>${mostrarValor(emp.sueldo_extra_final)}</td>
                <td>${mostrarValor(emp.neto_pagar)}</td>
                <td>${mostrarValor(emp.prestamo)}</td>
                <td>${mostrarValor(emp.inasistencias_descuento)}</td>
                <td>${mostrarValor(emp.uniformes)}</td>
                <td>${mostrarValor(infonavit)}</td>
                <td>${mostrarValor(isr)}</td>
                <td>${mostrarValor(imss)}</td>
                <td>${mostrarValor(emp.checador)}</td>
                <td>${mostrarValor(emp.fa_gafet_cofia)}</td>
                <td class="${claseSueldo}">${mostrarValor(emp.sueldo_a_cobrar)}</td>
            </tr>
        `;
        $('#tabla-sin-seguro-body').append(fila);
    });
    
    // Re-inicializar el menú contextual después de renderizar la tabla
    inicializarMenuContextualSinSeguro();
    // Aplicar colores de puestos
    aplicarColoresPuestosEnTabla('#tabla-sin-seguro-body');
}

// Función para renderizar paginación de empleados sin seguro
function renderPaginacionSinSeguro() {
    const totalPaginas = Math.ceil(empleadosSinSeguroPaginados.length / empleadosPorPaginaSinSeguro);
    let html = '';
    
    if (totalPaginas > 1) {
        // Botón anterior
        html += `<li class="page-item${paginaActualSinSeguro === 1 ? ' disabled' : ''}">
            <a class="page-link" href="#" onclick="cambiarPaginaSinSeguro(${paginaActualSinSeguro - 1}); return false;">&laquo;</a>
        </li>`;
        
        // Determinar qué números de página mostrar
        const paginasVisibles = 5; // Número de páginas a mostrar además de la primera y última
        const paginas = [];
        
        // Siempre agregar la primera página
        paginas.push(1);
        
        // Calcular el rango alrededor de la página actual
        const inicio = Math.max(2, paginaActualSinSeguro - Math.floor(paginasVisibles/2));
        const fin = Math.min(totalPaginas - 1, inicio + paginasVisibles - 1);
        
        // Agregar ellipsis después de la página 1 si es necesario
        if (inicio > 2) {
            paginas.push('...');
        }
        
        // Agregar páginas del rango calculado
        for (let i = inicio; i <= fin; i++) {
            paginas.push(i);
        }
        
        // Agregar ellipsis antes de la última página si es necesario
        if (fin < totalPaginas - 1) {
            paginas.push('...');
        }
        
        // Siempre agregar la última página si hay más de una página
        if (totalPaginas > 1) {
            paginas.push(totalPaginas);
        }
        
        // Generar HTML para cada número de página o ellipsis
        paginas.forEach(pagina => {
            if (pagina === '...') {
                html += `<li class="page-item disabled"><a class="page-link" href="#">...</a></li>`;
            } else {
                html += `<li class="page-item${paginaActualSinSeguro === pagina ? ' active' : ''}">
                    <a class="page-link" href="#" onclick="cambiarPaginaSinSeguro(${pagina}); return false;">${pagina}</a>
                </li>`;
            }
        });
        
        // Botón siguiente
        html += `<li class="page-item${paginaActualSinSeguro === totalPaginas ? ' disabled' : ''}">
            <a class="page-link" href="#" onclick="cambiarPaginaSinSeguro(${paginaActualSinSeguro + 1}); return false;">&raquo;</a>
        </li>`;
    }
    
    $("#paginacion-sin-seguro").html(html);
}

// Función para cambiar página en empleados sin seguro
function cambiarPaginaSinSeguro(nuevaPagina) {
    const totalPaginas = Math.ceil(empleadosSinSeguroPaginados.length / empleadosPorPaginaSinSeguro);
    if (nuevaPagina < 1 || nuevaPagina > totalPaginas) return;
    paginaActualSinSeguro = nuevaPagina;
    renderTablaSinSeguroPaginada();
}

// Función para obtener empleados del departamento "SIN SEGURO"
function obtenerEmpleadosSinSeguro(filtroPuesto = 'Produccion 40 Libras') {
    let empleadosSinSeguro = [];
    if (jsonGlobal && jsonGlobal.departamentos) {
        jsonGlobal.departamentos.forEach(depto => {
            if ((depto.nombre || '').toUpperCase().includes('SIN SEGURO')) {
                let empleadosFiltrados = (depto.empleados || []).slice();
                
                // Aplicar filtro por categoría de peso
                empleadosFiltrados = empleadosFiltrados.filter(emp => {
                    return emp.puesto === filtroPuesto;
                });
                
                // Ordenar por apellidos
                let empleadosOrdenados = empleadosFiltrados.sort(compararPorApellidos);
                
                empleadosOrdenados.forEach(emp => {
                    empleadosSinSeguro.push({
                        ...emp,
                        id_departamento: depto.nombre.split(' ')[0],
                        nombre_departamento: depto.nombre.replace(/^\d+\s*/, ''),
                        puesto: emp.puesto || emp.nombre_departamento || depto.nombre.replace(/^\d+\s*/, '')
                    });
                });
            }
        });
    }
    return empleadosSinSeguro;
}

// Función para mostrar empleados sin seguro
function mostrarEmpleadosSinSeguro(mantenerPagina = true, filtroPuesto = 'Produccion 40 Libras') {
    const empleadosSinSeguro = obtenerEmpleadosSinSeguro(filtroPuesto);
    setEmpleadosSinSeguroPaginados(empleadosSinSeguro, mantenerPagina);
}

// Hacer las funciones disponibles globalmente
window.mostrarEmpleadosSinSeguro = mostrarEmpleadosSinSeguro;
window.obtenerEmpleadosSinSeguro = obtenerEmpleadosSinSeguro;

