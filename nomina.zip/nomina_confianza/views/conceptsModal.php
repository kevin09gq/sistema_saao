<div class="modal-detalles" id="modal-detalles" style="display:none;">
    <div class="modal-detalles-content">
        <span class="modal-detalles-close" id="cerrar-modal-detalles">&times;</span>
        <ul class="nav nav-tabs mb-3" id="modalTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="tab-info" data-bs-toggle="tab" data-bs-target="#tab_info" type="button" role="tab" aria-controls="tab_info" aria-selected="true">
                    Trabajador
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="tab-registros" data-bs-toggle="tab" data-bs-target="#tab_registros" type="button" role="tab" aria-controls="tab_registros" aria-selected="false">
                    Registros
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="tab-modificar-detalles" data-bs-toggle="tab" data-bs-target="#tab_modificar_detalles" type="button" role="tab" aria-controls="tab_modificar_detalles" aria-selected="false">
                    Modificar Detalles
                </button>
            </li>
        </ul>
        <style>
            /* Aumentar tamaño y altura de controles de hora dentro del modal */
            .modal-detalles input[type="time"] {
                font-size: 1.05rem; /* texto más grande */
                padding: .5rem .75rem;
                height: 46px;
                line-height: 1.2;
                border-radius: .375rem;
            }

            /* Inputs específicos: ocupar todo el ancho de su columna */
            #input-entrada-copiar,
            #input-salida-comida-copiar,
            #input-entrada-comida-copiar,
            #input-salida-copiar {
                width: 100%;
                font-size: 1.05rem;
            }

            /* Separación entre columnas (gaps visibles) */
            .horarios-copiar-row {
                gap: 1rem; /* espacio horizontal entre columnas (si el navegador soporta gap) */
            }

            /* Mejorar legibilidad de las horas mostradas en la tabla de horarios */
            #tabla-horarios-oficiales .custom-table td {
                font-size: 0.98rem;
                vertical-align: middle;
            }

            /* Icono del botón copiar ligeramente más pequeño y centrado */
            #btn-copiar-horarios i {
                font-size: 0.95rem;
                margin-right: .35rem;
            }

            /* Responsive: en pantallas pequeñas hacer que los inputs ocupen todo el ancho disponible */
            @media (max-width: 575.98px) {
                #input-entrada-copiar,
                #input-salida-comida-copiar,
                #input-entrada-comida-copiar,
                #input-salida-copiar {
                    width: 100%;
                }

                .horarios-copiar-row {
                    display: flex;
                    flex-direction: column;
                }

                .horarios-copiar-row .col-md-2 {
                    width: 100%;
                }
            }
        </style>
        <div class="tab-content">
            <!-- Info Trabajador -->
            <div class="tab-pane fade show active" id="tab_info" role="tabpanel" aria-labelledby="tab-info">
                <h4 class="tab-title">Detalles del empleado</h4>

                <!-- Información básica del empleado -->
                <div class="empleado-info">
                    <div class="info-row">
                        <span class="info-label">Clave:</span>
                        <span class="info-value" id="campo-clave"></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Nombre:</span>
                        <span class="info-value" id="campo-nombre"></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Departamento:</span>
                        <span class="info-value" id="campo-departamento"></span>
                    </div>
                    <!-- Campo oculto para almacenar id_empresa -->
                    <input type="" id="campo-id-empresa" value="">
                </div>
            </div>

            <!-- Registros -->
            <div class="tab-pane fade" id="tab_registros" role="tabpanel" aria-labelledby="tab-registros">
                <h4 class="tab-title">Registros de Entrada y Salida</h4>

                <!-- Botones para cambiar vista como mini-tabs -->
                <div class="d-flex justify-content-center mb-3">
                    <div class="btn-group" role="group" aria-label="Vista de registros">
                        <button type="button" class="btn btn-outline-success mini-tab-registros active" id="btn-biometrico">
                            <i class="bi bi-check-circle"></i> biometrico
                        </button>
                        <button type="button" class="btn btn-outline-primary mini-tab-registros" id="btn-horarios-oficiales">
                            <i class="bi bi-clock-history"></i> horarios-oficiales
                        </button>
                    </div>
                </div>

                <!-- Tabla de Registros del Checador -->
                <div class="table-container" id="tabla-checador">
                    <table class=" custom-table">
                        <thead>
                            <tr>
                                <th>Día</th>
                                <th>Fecha</th>
                                <th>Entrada</th>
                                <th>Salida</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Los datos se llenarán con JavaScript -->
                        </tbody>
                    </table>
                </div>


                <!-- Tabla de Registros BD -->
                <div class="table-container" id="tabla-horarios-oficiales" hidden>
                    <!-- Campos de entrada rápida para copiar a todos los días -->
                    <div class="card bg-light mb-3">
                        <div class="card-body">
                           
                

                            <div class="row gx-3 gy-2 align-items-end horarios-copiar-row">
                                <div class="col-md-3 col-sm-6">
                                    <label class="form-label fw-semibold small">Entrada</label>
                                    <input type="time" step="60" class="form-control form-control-sm" id="input-entrada-copiar" placeholder="HH:MM">
                                </div>
                                <div class="col-md-3 col-sm-6">
                                    <label class="form-label fw-semibold small">Salida Comida</label>
                                    <input type="time" step="60" class="form-control form-control-sm" id="input-salida-comida-copiar" placeholder="HH:MM">
                                </div>
                                <div class="col-md-3 col-sm-6">
                                    <label class="form-label fw-semibold small">Entrada Comida</label>
                                    <input type="time" step="60" class="form-control form-control-sm" id="input-entrada-comida-copiar" placeholder="HH:MM">
                                </div>
                                <div class="col-md-3 col-sm-6">
                                    <label class="form-label fw-semibold small">Salida</label>
                                    <input type="time" step="60" class="form-control form-control-sm" id="input-salida-copiar" placeholder="HH:MM">
                                </div>
                                <div class="col-md-3 d-flex justify-content-end align-items-end">
                                    <button type="button" class="btn btn-primary btn-sm" id="btn-copiar-horarios" title="Copiar a Todos los Días" aria-label="Copiar a Todos los Días">
                                        <i class="bi bi-clipboard-check"></i> Copiar
                                    </button>
                                </div>
                            </div>
                           
                        </div>
                    </div>

                    <table class="custom-table">
                        <thead>
                            <tr>
                                <th>Día</th>
                                <th>Entrada</th>
                                <th>Salida Comida</th>
                                <th>Entrada Comida</th>
                                <th>Salida</th>

                            </tr>
                        </thead>
                        <tbody id="horarios-oficiales-body">
                            <!-- Los datos se llenarán con JavaScript -->

                        </tbody>

                    </table>
                </div>

                <!-- Eventos Especiales -->
                <div class="eventos-especiales-container">
                    <h5 class="eventos-title">
                        <i class="bi bi-clock-history"></i> Eventos Especiales
                    </h5>

                   
                    <!-- Primera fila: Entradas Tempranas y Salidas Tardías -->
                    <div class="row">
                        <!-- Entradas Tempranas -->
                        <div class="col-md-6 mb-3">
                            <div class="evento-card entrada-temprana">
                                <div class="evento-header">
                                    <i class="bi bi-sunrise"></i>
                                    <span>Entradas Tempranas</span>
                                </div>
                                <div class="evento-content" id="entradas-tempranas-content">

                                </div>
                                <div class="evento-total">
                                    <strong>Total: <span id="total-entradas-tempranas"></span></strong>
                                </div>
                            </div>
                        </div>

                        <!-- Salidas Tardías -->
                        <div class="col-md-6 mb-3">
                            <div class="evento-card salida-tardia">
                                <div class="evento-header">
                                    <i class="bi bi-sunset"></i>
                                    <span>Salidas Tardías</span>
                                </div>
                                <div class="evento-content" id="salidas-tardias-content">

                                </div>
                                <div class="evento-total">
                                    <strong>Total: <span id="total-salidas-tardias"></span></strong>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Segunda fila: Salidas Tempranas y Olvidos del Checador -->
                    <div class="row">
                         <!-- Salidas Tempranas -->
                        <div class="col-md-6 mb-3">
                            <div class="evento-card salida-temprana">
                                <div class="evento-header">
                                    <i class="bi bi-clock"></i>
                                    <span>Salidas Tempranas</span>
                                </div>
                                <div class="evento-content" id="salidas-tempranas-content">

                                </div>
                                <div class="evento-total">
                                    <strong>Total: <span id="total-salidas-tempranas"></span></strong>
                                </div>
                            </div>
                        </div>

                        <!-- Olvidos del Checador -->
                        <div class="col-md-6 mb-3">
                            <div class="evento-card olvido-checador" id="olvidos-checador-card">
                                <div class="evento-header">
                                    <i class="bi bi-exclamation-triangle"></i>
                                    <span>Olvidos del Checador</span>
                                </div>
                                <div class="evento-content" id="olvidos-checador-content">

                                </div>
                                <div class="evento-total">
                                    <strong>Total: <span id="total-olvidos-checador"></span></strong>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Tercera fila: Retardos y Faltas -->
                    <div class="row">
                        <!-- Retardos -->
                        <div class="col-md-6 mb-3">
                            <div class="evento-card retardo" id="retardos-card">
                                <div class="evento-header">
                                    <i class="bi bi-clock-fill"></i>
                                    <span>Retardos</span>
                                </div>
                                <div class="evento-content" id="retardos-content">

                                </div>
                                <div class="evento-total">
                                    <strong>Total: <span id="total-retardos"></span></strong>
                                </div>
                            </div>
                        </div>
                        <!-- Faltas -->
                        <div class="col-md-6 mb-3">
                            <div class="evento-card falta" id="faltas-card">
                                <div class="evento-header">
                                    <i class="bi bi-x-circle"></i>
                                    <span>Faltas (Días sin registro con horario oficial)</span>
                                </div>
                                <div class="evento-content" id="faltas-content">

                                </div>
                                <div class="evento-total">
                                    <strong>Total: <span id="total-faltas"></span></strong>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Cuarta fila: Análisis de Permisos y Comidas -->
                    <div class="row">
                        <!-- Análisis de Permisos y Comidas -->
                        <div class="col-md-12 mb-3">
                            <div class="evento-card analisis-permisos" style="border-color: #9b59b6;">
                                <div class="evento-header" style="background: linear-gradient(135deg, #9b59b6 0%, #8e44ad 100%);">
                                    <i class="bi bi-diagram-3"></i>
                                    <span>Análisis de Permisos y Comidas</span>
                                </div>
                                <div class="evento-content" id="analisis-permisos-comida-content" style="max-height: 400px; overflow-y: auto;">

                                </div>
                                <div class="evento-total">
                                    <strong>Total: <span id="total-analisis-permisos-comida"></span></strong>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>

            </div>
            <!-- Modificar Detalles -->
            <div class="tab-pane fade" id="tab_modificar_detalles" role="tabpanel" aria-labelledby="tab-modificar-detalles">
                <h4 class="mod-detalles-title"><i class="bi bi-pencil-square"></i> Modificar Detalles</h4>
                <form id="form-modificar-sueldo">
                    <div class="card shadow-sm mb-3 mod-card">
                        <div class="card-header mod-card-header-azul">
                            <i class="bi bi-cash-coin"></i> Percepciones
                        </div>
                        <div class="card-body mod-card-body-azul">
                            <!-- Primera fila: Campos principales con altura fija -->
                            <div class="row mb-4">
                                <div class="col-md-6 d-flex flex-column">
                                    <label class="form-label fw-semibold">Sueldo Semanal ($)</label>
                                    <div class="flex-grow-1 d-flex align-items-end">
                                        <input type="number" step="0.01" class="form-control mod-input-azul" id="mod-sueldo-semanal" value="" placeholder="0.00">
                                    </div>
                                </div>

                                <div class="col-md-6 d-flex flex-column">
                                    <label class="form-label fw-semibold">Total Sueldo Extra ($)</label>
                                    <small class="text-muted mb-1">Calculado automáticamente</small>
                                    <input type="number" step="0.01" class="form-control mod-input-azul mod-input-readonly" id="mod-total-extra" value="" placeholder="0.00" readonly>
                                </div>
                            </div>

                            <!-- Separador visual -->
                            <hr class="mod-separador">

                            <!-- Título de componentes -->
                            <div class="row mb-3">
                                <div class="col-12">
                                    <h6 class="componentes-title">
                                        <i class="bi bi-list-ul"></i> Componentes del Sueldo Extra
                                    </h6>
                                    <small class="componentes-subtitle">Configure los diferentes conceptos que conforman el sueldo extra</small>
                                </div>
                            </div>

                            <!-- Componentes organizados con altura uniforme -->
                            <div class="row" id="componentes-sueldo-extra">
                                <div class="col-md-3 mb-3 d-flex flex-column">
                                    <label class="form-label fw-normal">Vacaciones</label>
                                    <div class="flex-grow-1 d-flex align-items-end">
                                        <input type="number" step="0.01" class="form-control mod-input-azul componente-extra" id="mod-vacaciones" value="" placeholder="0.00">
                                    </div>
                                </div>

                            </div>

                            <!-- Contenedor para conceptos adicionales -->
                            <div class="row" id="contenedor-conceptos-adicionales">
                                <!-- Los conceptos adicionales se cargarán aquí dinámicamente -->
                            </div>

                            <!-- Botón para agregar más conceptos -->
                            <div class="row">
                                <div class="col-12 text-center">
                                    <button type="button" class="btn btn-outline-primary btn-sm" id="btn-agregar-concepto">
                                        <i class="bi bi-plus-circle"></i> Agregar Otro Concepto
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card shadow-sm mb-3 mod-card">
                        <div class="card-header mod-card-header-amarillo">
                            <i class="bi bi-dash-circle"></i> Conceptos
                        </div>
                        <div class="card-body mod-card-body-amarillo">
                            <div class="row mb-3">
                                <div class="col-md-4 mb-2">
                                    <label class="form-label fw-semibold">ISR ($)</label>
                                    <div class="input-group">
                                        <input type="number" step="0.01" class="form-control mod-input-amarillo" id="mod-isr" value="" placeholder="0.00">
                                        <button type="button" class="btn btn-outline-secondary" id="btn-aplicar-isr" title="Aplicar Nuevo ISR">
                                            <i class="bi bi-calculator"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-2">
                                    <label class="form-label fw-semibold">IMSS ($)</label>
                                    <div class="input-group">
                                        <input type="number" step="0.01" class="form-control mod-input-amarillo" id="mod-imss" value="" placeholder="0.00">
                                        <button type="button" class="btn btn-outline-secondary" id="btn-aplicar-imss" title="Aplicar Nuevo IMSS">
                                            <i class="bi bi-calculator"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-2">
                                    <label class="form-label fw-semibold">INFONAVIT ($)</label>
                                    <div class="input-group">
                                        <input type="number" step="0.01" class="form-control mod-input-amarillo" id="mod-infonavit" value="" placeholder="0.00">
                                        <button type="button" class="btn btn-outline-secondary" id="btn-aplicar-infonavit" title="Aplicar Nuevo INFONAVIT">
                                            <i class="bi bi-calculator"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-4 mb-2">
                                    <label class="form-label fw-semibold">AJUSTES AL SUB ($)</label>
                                    <div class="input-group">
                                        <input type="number" step="0.01" class="form-control mod-input-amarillo" id="mod-ajustes-sub" value="" placeholder="0.00">
                                        <button type="button" class="btn btn-outline-secondary" id="btn-aplicar-ajuste-sub" title="Aplicar Nuevo Ajuste al Sub">
                                            <i class="bi bi-calculator"></i>
                                        </button>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="card shadow-sm mb-3 mod-card">
                        <div class="card-header mod-card-header-rosa">
                            <i class="bi bi-dash-circle"></i> Deducciones
                        </div>
                        <div class="card-body mod-card-body-rosa">
                            <!-- Primera fila: Tarjeta, Préstamo -->
                            <div class="row mb-3">
                                <div class="col-md-6 mb-2">
                                    <label class="form-label fw-semibold">Tarjeta ($)</label>
                                    <div class="input-group">
                                        <input type="number" step="0.01" class="form-control mod-input-rosa" id="mod-tarjeta" value="" placeholder="0.00">
                                        <button type="button" class="btn btn-outline-secondary" id="btn-aplicar-tarjeta" title="Aplicar Nueva Tarjeta">
                                            <i class="bi bi-credit-card"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-2">
                                    <label class="form-label fw-semibold">Préstamo ($)</label>
                                    <div class="input-group">
                                        <input type="number" step="0.01" class="form-control mod-input-rosa" id="mod-prestamo" value="" placeholder="0.00">
                                        <button type="button" class="btn btn-outline-primary" id="btn-ver-prestamos" title="Ver Préstamos">
                                            <i class="bi bi-cash-stack"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Separador visual -->
                            <hr class="mod-separador">

                            <!-- Sección de Checador -->
                            <div class="row mb-3">
                                <div class="col-12">
                                    <h6 class="fw-semibold text-warning mb-3">
                                        <i class="bi bi-exclamation-triangle"></i> Checador
                                    </h6>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-4 mb-2">
                                    <label class="form-label fw-semibold">Checador ($)</label>
                                    <div class="input-group">
                                        <input type="number" step="0.01" class="form-control mod-input-rosa" id="mod-checador" value="" placeholder="0.00">
                                        <button type="button" class="btn btn-outline-secondary" id="btn-calcular-checador" title="Calcular desde historial">
                                            <i class="bi bi-calculator"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Historial Detallado de Olvidos -->
                            <div class="row mb-3">
                                <div class="col-12">
                                    <h6 class="fw-semibold text-warning mb-3">
                                        <i class="bi bi-exclamation-triangle-fill"></i> Historial de Olvidos por Día
                                    </h6>
                                    <div id="contenedor-historial-olvidos" class="historial-olvidos-container">
                                        <!-- Se llenará con JavaScript -->
                                    </div>
                                </div>
                            </div>

                            <!-- Separador visual -->
                            <hr class="mod-separador">

                            <!-- Sección de Retardos -->
                            <div class="row mb-3">
                                <div class="col-12">
                                    <h6 class="fw-semibold text-danger mb-3">
                                        <i class="bi bi-clock-fill"></i> Retardos
                                    </h6>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-4 mb-2">
                                    <label class="form-label fw-semibold">Total Retardos ($)</label>
                                    <div class="input-group">
                                        <input type="number" step="0.01" class="form-control mod-input-rosa" id="mod-retardos" value="" placeholder="0.00">
                                        <button type="button" class="btn btn-outline-secondary" id="btn-calcular-retardos" title="Calcular desde historial">
                                            <i class="bi bi-calculator"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Historial Detallado de Retardos -->
                            <div class="row mb-3">
                                <div class="col-12">
                                    <h6 class="fw-semibold text-info mb-3">
                                        <i class="bi bi-calendar-check"></i> Historial de Retardos por Día
                                    </h6>
                                    <div id="contenedor-historial-retardos" class="historial-retardos-container">
                                        <!-- El historial se cargará dinámicamente aquí -->
                                    </div>
                                </div>
                            </div>

                            <!-- Separador visual -->
                            <hr class="mod-separador">

                            <!-- Sección de Uniformes -->
                            <div class="row mb-3">
                                <div class="col-md-4 mb-2">
                                    <label class="form-label fw-semibold">Uniformes ($)</label>
                                    <input type="number" step="0.01" class="form-control mod-input-rosa" id="mod-uniformes" value="" placeholder="0.00" readonly>
                                </div>
                            </div>

                            <!-- Historial Detallado de Uniformes -->
                            <div class="row mb-3">
                                <div class="col-12">
                                    <h6 class="fw-semibold text-primary mb-3">
                                        <i class="bi bi-tags-fill"></i> Historial de Uniformes
                                    </h6>

                                    <!-- Formulario para agregar folio -->
                                    <div class="card bg-light mb-3">
                                        <div class="card-body">
                                            <div class="row g-2 align-items-end">
                                                <div class="col-md-4">
                                                    <label class="form-label fw-semibold small">Folio</label>
                                                    <input type="text" class="form-control form-control-sm" id="input-folio-uniforme" placeholder="Ej: UNI-001" maxlength="50">
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="form-label fw-semibold small">Cantidad ($)</label>
                                                    <input type="number" step="0.01" class="form-control form-control-sm" id="input-cantidad-uniforme" placeholder="0.00" min="0">
                                                </div>
                                                <div class="col-md-4">
                                                    <button type="button" class="btn btn-success btn-sm w-100" id="btn-agregar-folio-uniforme">
                                                        <i class="bi bi-plus-circle"></i> Agregar Folio
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Contenedor del historial -->
                                    <div id="contenedor-historial-uniformes" class="historial-uniformes-container">
                                        <!-- Se llenará con JavaScript -->
                                    </div>
                                </div>
                            </div>

                            <!-- Separador visual -->
                            <hr class="mod-separador">

                            <!-- Sección de Permisos -->
                            <div class="row mb-3">
                                <div class="col-12">
                                    <h6 class="fw-semibold text-warning mb-3">
                                        <i class="bi bi-clock-fill"></i> Permisos
                                    </h6>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-4 mb-2">
                                    <label class="form-label fw-semibold">Permisos ($)</label>
                                    <div class="input-group">
                                        <input type="number" step="0.01" class="form-control mod-input-rosa" id="mod-permiso" value="" placeholder="0.00" readonly>
                                        
                                    </div>
                                </div>
                            </div>

                            <!-- Historial Detallado de Permisos -->
                            <div class="row mb-3">
                                <div class="col-12">
                                    <h6 class="fw-semibold text-warning mb-3">
                                        <i class="bi bi-clock-history"></i> Historial de Permisos
                                    </h6>

                                    <!-- Formulario para agregar permiso -->
                                    <div class="card bg-light mb-3">
                                        <div class="card-body">
                                            <div class="row g-2 align-items-end">
                                                <div class="col-md-4">
                                                    <label class="form-label fw-semibold small">Descripción</label>
                                                    <input type="text" class="form-control form-control-sm" id="input-descripcion-permiso" placeholder="Ej: Permiso médico" maxlength="100">
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="form-label fw-semibold small">Minutos</label>
                                                    <input type="text" class="form-control form-control-sm" id="input-minutos-permiso" placeholder="Ej: 150" maxlength="20">
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="form-label fw-semibold small">Costo x Min ($)</label>
                                                    <input type="number" step="0.01" class="form-control form-control-sm" id="input-cantidad-permiso" placeholder="0.00" min="0">
                                                </div>
                                                <div class="col-md-2">
                                                    <button type="button" class="btn btn-warning btn-sm w-100" id="btn-agregar-permiso">
                                                        <i class="bi bi-plus-circle"></i> Agregar
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Contenedor del historial -->
                                    <div id="contenedor-historial-permisos" class="historial-permisos-container">
                                        <!-- Se llenará con JavaScript -->
                                    </div>
                                </div>
                            </div>

                            <!-- Separador visual -->
                            <hr class="mod-separador">

                            <!-- Sección de Inasistencias -->
                            <div class="row mb-3">
                                <div class="col-12">
                                    <h6 class="fw-semibold text-info mb-3">
                                        <i class="bi bi-calendar-x"></i> Inasistencias
                                    </h6>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-4 mb-2">
                                    <label class="form-label fw-semibold">Inasistencias($)</label>
                                    <div class="input-group">
                                        <input type="number" step="0.01" class="form-control mod-input-rosa" id="mod-inasistencias" value="" placeholder="0.00">
                                        <button type="button" class="btn btn-outline-secondary" id="btn-calcular-inasistencias" title="Calcular desde historial">
                                            <i class="bi bi-calculator"></i>
                                        </button>
                                    </div>
                                </div>
                                
                            </div>

                            <!-- Historial Detallado de Inasistencias -->
                            <div class="row mb-3">
                                <div class="col-12">
                                    <h6 class="fw-semibold text-info mb-3">
                                        <i class="bi bi-calendar-x"></i> Historial de Inasistencias por Día
                                    </h6>
                                    
                                    <!-- Formulario para agregar inasistencia manual -->
                                    <div class="card bg-light mb-3">
                                        <div class="card-body">
                                            <div class="row g-2 align-items-end">
                                                <div class="col-md-4">
                                                    <label class="form-label fw-semibold small">Día de la Semana</label>
                                                    <select class="form-select form-select-sm" id="select-dia-inasistencia">
                                                        <option value="">Seleccionar día...</option>
                                                        <option value="Lunes">Lunes</option>
                                                        <option value="Martes">Martes</option>
                                                        <option value="Miércoles">Miércoles</option>
                                                        <option value="Jueves">Jueves</option>
                                                        <option value="Viernes">Viernes</option>
                                                        <option value="Sábado">Sábado</option>
                                                        <option value="Domingo">Domingo</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="form-label fw-semibold small">Descuento ($)</label>
                                                    <input type="number" step="0.01" class="form-control form-control-sm" id="input-descuento-inasistencia" placeholder="0.00" min="0">
                                                </div>
                                                <div class="col-md-4">
                                                    <button type="button" class="btn btn-info btn-sm w-100" id="btn-agregar-inasistencia">
                                                        <i class="bi bi-plus-circle"></i> Agregar Inasistencia
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div id="contenedor-historial-inasistencias" class="historial-inasistencias-container">
                                        <!-- El historial se cargará dinámicamente aquí -->
                                    </div>
                                </div>
                            </div>

                            <!-- Separador visual -->
                            <hr class="mod-separador">

                            <!-- Sección de F.A/GAFET/COFIA -->
                            <div class="row mb-3">
                                <div class="col-md-4 mb-2">
                                    <label class="form-label fw-semibold">F.A/GAFET/COFIA ($)</label>
                                    <input type="number" step="0.01" class="form-control mod-input-rosa" id="mod-fa-gafet-cofia" value="" placeholder="0.00" readonly>
                                    <small class="text-muted">Suma automática de deducciones adicionales</small>
                                </div>
                            </div>


                            <div class="row" id="contenedor-deducciones-adicionales">
                            </div>
                            <div class="row">
                                <div class="col-12 text-center">
                                    <button type="button" class="btn btn-outline-danger btn-sm" id="btn-agregar-deduccion">
                                        <i class="bi bi-plus-circle"></i> Agregar Deducción Personalizada
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Sueldo a Cobrar -->
                    <div class="card shadow-sm mb-3 mod-card">
                        <div class="card-header mod-card-header-verde">
                            <i class="bi bi-currency-dollar"></i> Sueldo a Cobrar
                        </div>
                        <div class="card-body mod-card-body-verde">
                            <!-- Opciones de redondeo: checkbox + modo -->
                            <div class="row mb-3">
                                <div class="col-md-6 offset-md-3">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" id="mod-redondear-sueldo">
                                        <label class="form-check-label fw-semibold" for="mod-redondear-sueldo">Redondear sueldo a cobrar</label>
                                    </div>
                                    <div class="mt-2" id="mod-redondeo-opciones" style="display:none;">
                                        <select id="mod-redondeo-modo" class="form-select form-select-sm w-auto d-inline-block">
                                            <option value="nearest">Al entero más cercano</option>
                                            <option value="up">Hacia arriba</option>
                                            <option value="down">Hacia abajo</option>
                                        </select>
                                        <small class="text-muted ms-2">Modo de redondeo</small>
                                    </div>
                                </div>
                            </div>

                            <div class="row justify-content-center">
                                <div class="col-md-6 text-center">
                                    <label class="sueldo-cobrar-label">
                                        <i class="bi bi-cash-stack"></i> Total a Cobrar
                                    </label>
                                    <input type="number" step="0.01" class="sueldo-cobrar-input"
                                        id="mod-sueldo-a-cobrar" value="8">
                                    <small class="sueldo-cobrar-descripcion">
                                        <i class="bi bi-info-circle"></i>

                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>

                </form>
            </div>

        </div>
        <div class="modal-detalles-footer d-flex justify-content-between align-items-center">
            <div class="empleado-actual">
                <span class="badge bg-verde-empleado" id="nombre-empleado-modal"></span>
            </div>
            <div>
                <button type="button" id="btn-cancelar-conceptos" class="btn btn-secondary">Cancelar</button>
                <button type="button" id="btn-guardar-conceptos" class="btn btn-success">Guardar</button>
            </div>
        </div>
    </div>
</div>

