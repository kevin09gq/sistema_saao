// ========================================
// MENÚ CONTEXTUAL EN LA TABLA DE NÓMINA
// ========================================
const $menu = $('#context-menu');
let filaSeleccionada = null;

mostrarContextMenu();
abrirModal();


function mostrarContextMenu() {
    // Click derecho en fila de la tabla
    $('#tabla-nomina-body-palmilla').on('contextmenu', 'tr', function (e) {
        e.preventDefault();
        filaSeleccionada = $(this);

        // Obtener datos de la fila
        const clave = filaSeleccionada.data('clave');
        const idTipoPuesto = filaSeleccionada.data('id-tipo-puesto');
        const tipoHorario = parseInt(filaSeleccionada.data('tipo-horario'));

        // Posicionar y mostrar menú
        $menu.css({
            top: e.pageY + 'px',
            left: e.pageX + 'px'
        }).show();
    });

    // Cerrar menú al hacer click en otro lugar
    $(document).on('click', function () {
        $menu.hide();
    });
}

function abrirModal() {
    // Acciones del menú contextual
    $menu.on('click', '.cm-item', function () {
        const accion = $(this).data('action');
        if (accion === 'ver' && filaSeleccionada) {

            // Obtener tipo_horario de la fila seleccionada
            const tipoHorario = parseInt(filaSeleccionada.data('tipo-horario'));

            // Solo abrir modal si es Coordinador (tipo_horario 1)
            if (tipoHorario === 1) {
                // Obtener clave e id_empresa del empleado
                const clave = String(filaSeleccionada.data('clave') || '').trim();
                const idEmpresa = parseInt(filaSeleccionada.data('id-empresa')) || 1;

                // Buscar el empleado usando la función dedicada
                const empleadoEncontrado = buscarEmpleado(clave, idEmpresa);

                if (empleadoEncontrado) {
                    establerDataModalCoordinador(empleadoEncontrado);
                } else {
                    console.warn('Empleado no encontrado');
                }
            }
            // Si es tipo_horario 2 (Rancho/Jornalero)
            else if (tipoHorario === 2) {
                const clave = String(filaSeleccionada.data('clave') || '').trim();
                const idEmpresa = parseInt(filaSeleccionada.data('id-empresa')) || 1;
                const empleadoEncontrado = buscarEmpleado(clave, idEmpresa);
                if (empleadoEncontrado) {
                    establerDataModalJornalero(empleadoEncontrado);
                } else {
                    console.warn('Empleado no encontrado');
                }
            }
        }
        $menu.hide();
    });
}

// Función para buscar empleado por clave e id_empresa
function buscarEmpleado(clave, idEmpresa) {
    if (!jsonNominaPalmilla || !jsonNominaPalmilla.departamentos) {
        return null;
    }

    for (let depto of jsonNominaPalmilla.departamentos) {
        if (depto.empleados) {
            const empleado = depto.empleados.find(emp =>
                String(emp.clave || '').trim() === clave &&
                parseInt(emp.id_empresa) === idEmpresa
            );
            if (empleado) {
                return empleado;
            }
        }
    }
    return null;
}

