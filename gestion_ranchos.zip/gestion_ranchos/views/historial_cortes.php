<?php
require_once __DIR__ . '/../../config/config.php';
verificarSesion();
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historial Cortes - Ranchos</title>

    <link href="<?= BOOTSTRAP_CSS ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?= BOOTSTRAP_ICONS ?>">

    <script src="<?= SWEETALERT ?>"></script>

    <script>
        const rutaRaiz = '<?= $rutaRaiz ?>';
    </script>

    <style>
        /*
        En navbar_styles.css se habilitó abrir dropdowns con hover en escritorio.
        Para los 3 puntitos de acciones en tabla, queremos SOLO click.
        */
        @media (min-width: 992px) {
            .tb-action-dropdown:hover>.dropdown-menu:not(.show) {
                display: none !important;
            }

            .tb-action-dropdown>.dropdown-menu.show {
                display: block !important;
            }
        }
    </style>
</head>

<body>
    <?php require_once __DIR__ . '/../../public/views/navbar.php'; ?>

    <div class="container-fluid bg-light py-4">
        <div class="container">
            <!-- Título y Botón -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="fw-bold">Historial de Vales de Corte</h2>
                <button type="button" class="btn btn-primary fw-bold" id="btn_nuevo_vale">
                    <i class="bi bi-plus-lg"></i> Agregar
                </button>
            </div>

            <!-- Sección de Filtrado -->
            <div class="card mb-4 shadow-sm">
                <div class="card-body">
                    <h5 class="text-muted mb-3"><i class="bi bi-funnel me-2"></i>Opciones de Búsqueda</h5>

                    <form class="row g-3" id="form_filtros">
                        <div class="col-md-3">
                            <label class="form-label fw-bold" for="select_rancho">Seleccionar Rancho *</label>
                            <select class="form-select" id="select_rancho">
                                <option value="-1" selected>--- Seleccionar ---</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-bold" for="select_anio">Seleccionar Año</label>
                            <select class="form-select" id="select_anio">
                                <option value="-1" selected>--- Seleccionar ---</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-bold" for="select_mes">Seleccionar Mes</label>
                            <select class="form-select" id="select_mes">
                                <option value="-1" selected>--- Seleccionar ---</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-bold" for="input_semana">Seleccionar Semana</label>
                            <select class="form-select" id="select_semana">
                                <option value="-1" selected>--- Seleccionar ---</option>
                            </select>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-success fw-bold" id="btn_filtrar">
                                <i class="bi bi-search me-2"></i>Buscar Historial
                            </button>
                        </div>
                        <span class="my-0 text-muted">* Campo obligatorio</span>
                    </form>
                </div>
            </div>

            <!-- Tarjetas de Resumen - Estilo Moderno -->
            <div class="row mb-4 d-none" id="seccion_tarjetas_resumen">
                <!-- Total Rejas -->
                <div class="col-md-4">
                    <div class="card shadow-sm h-100" id="card_total_rejas_extra">
                        <div class="card-body d-flex align-items-center">
                            <div class="bg-success bg-opacity-10 p-3 rounded-3 me-3 text-success">
                                <i class="bi bi-box-seam fs-4"></i>
                            </div>
                            <div>
                                <h6 class="text-muted mb-0">Total Rejas</h6>
                                <p class="fs-4 fw-bold mb-0" id="label_total_rejas_general">1,250</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Total Gastos -->
                <div class="col-md-4">
                    <div class="card shadow-sm h-100" id="card_total_gastos_extra">
                        <div class="card-body d-flex align-items-center">
                            <div class="bg-danger bg-opacity-10 p-3 rounded-3 me-3 text-danger">
                                <i class="bi bi-cash-stack fs-4"></i>
                            </div>
                            <div>
                                <h6 class="text-muted mb-0">Total Gastos</h6>
                                <p class="fs-4 fw-bold mb-0" id="label_total_gastos_general">$ 45,200.00</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tabla con más rejas -->
                <div class="col-md-4">
                    <div class="card shadow-sm h-100" id="card_tabla_mayor_extra">
                        <div class="card-body d-flex align-items-center">
                            <div class="bg-warning bg-opacity-10 p-3 rounded-3 me-3 text-warning">
                                <i class="bi bi-grid-3x3-gap fs-4"></i>
                            </div>
                            <div>
                                <h6 class="text-muted mb-0">Mayor Producción</h6>
                                <p class="fs-4 fw-bold mb-0" id="label_tabla_mas_rejas_general">T4 / 1,250 rejas</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tabla de Resultados en Card -->
            <div class="card shadow-sm mb-5 d-none" id="seccion_tabla_resultados">
                <!-- Header del card con título y acciones -->
                <div class="card-header bg-white py-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0 fw-bold">Desglose Detallado de Cortes</h5>
                        <div>
                            <button type="button" class="btn btn-sm btn-warning fw-bold me-2" id="btn_ranking_extra">
                                <i class="bi bi-trophy me-2"></i>Ranking
                            </button>
                            <button type="button" class="btn btn-sm btn-danger fw-bold" id="btn_exportar_pdf_extra">
                                <i class="bi bi-file-pdf me-2"></i>Exportar PDF
                            </button>
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <table class="table table-sm table-hover align-middle" id="tabla_vales_extra">
                        <thead class="table-light">
                            <tr>
                                <th class="text-center">N</th>
                                <th>Nómina</th>
                                <th>Folio</th>
                                <th>Fecha<br>Corte</th>
                                <th>Cortador</th>
                                <th>Tablas<br>Involucradas</th>
                                <th>Total<br>Rejas</th>
                                <th>Estado</th>
                                <th>Opciones</th>
                            </tr>
                        </thead>
                        <tbody id="cuerpo_tabla_historial_corte">
                            <!-- Los datos de la tabla se llenarán dinámicamente mediante JavaScript -->
                        </tbody>
                    </table>

                    <!-- Paginación -->
                    <div class="d-flex justify-content-between align-items-center mt-3" id="contenedor_paginacion">
                        <div class="text-muted small" id="info_paginacion">
                            Mostrando 0 a 0 de 0 registros
                        </div>
                        <nav aria-label="Navegación de cortes">
                            <ul class="pagination pagination-sm mb-0" id="paginas_lista">
                                <!-- Se llena dinámicamente con JS -->
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>

        <!-- IMPORTAR LOS MODALES -->
        <?php require_once __DIR__ . '/modal_detalles_corte.php'; ?>    
        <?php require_once __DIR__ . '/modal_nuevo_vale.php'; ?>
        <?php require_once __DIR__ . '/modal_editar_vale.php'; ?>
    </div>

    <!-- Bibliotecas JS -->
    <script src="<?= JQUERY_JS ?>"></script>
    <script src="<?= BOOTSTRAP_JS ?>"></script>

    <!-- Script personalizado para la página -->
    <script src="../js/historial_corte.js"></script>
    <script src="../js/utilidades.js"></script>


</body>

</html>