/**
 * Función para mostrar alertas usando SweetAlert2
 * @param {String} icono Iconos: success, error, warning, info, question.
 * @param {String} titulo Titulo prinicipal de la alerta.
 * @param {String} texto Mensaje principal de la alerta.
 * @param {Boolean} toast True para mostrar como toast, false para modal tradicional. Valor por defecto: false.
 * @param {Number} tiempo Duración del toast en ms (si toast=true). Valor por defecto: 3000ms.
 */
function alerta(icono, titulo, texto, toast = false, tiempo = 3000) {
    if (toast) {
        const Toast = Swal.mixin({
            toast: true,
            position: "top-end",
            showConfirmButton: false,
            timer: tiempo,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.onmouseenter = Swal.stopTimer;
                toast.onmouseleave = Swal.resumeTimer;
            }
        });
        Toast.fire({
            icon: icono,
            title: titulo
        });
    } else {
        // Modal tradicional
        Swal.fire({
            title: titulo,
            text: texto,
            icon: icono,
            confirmButtonText: "Entendido"
        });
    }
}

/**
 * Quita la palabra "Rancho" al inicio y convierte el resto en mayúsculas
 * @param {string} texto Cadena de entrada
 * @returns {string} Cadena sin "Rancho" y en mayúsculas
 */
function quitarPalabraRancho(texto) {
    if (!texto) return "";

    // Eliminar "Rancho" al inicio (con o sin espacios)
    const sinRancho = texto.replace(/^Rancho\s*/i, "");

    // Convertir a mayúsculas
    return sinRancho.toUpperCase();
}

/**
 * Convierte una fecha "YYYY-MM-DD" a "DD/Mes/AAAA"
 * @param {string} fecha Cadena en formato "YYYY-MM-DD"
 * @returns {string} Fecha formateada como "13/Ene/2026"
 */
function formatearFechaEspa(fecha) {
    // Array con abreviaturas de meses
    const meses = ["Ene", "Feb", "Mar", "Abr", "May", "Jun",
                   "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"];

    // Separar la fecha en partes
    const [anio, mes, dia] = fecha.split("-");

    // Obtener nombre del mes (restamos 1 porque el array empieza en 0)
    const nombreMes = meses[parseInt(mes, 10) - 1];

    // Retornar en formato deseado
    return `${parseInt(dia, 10)}/${nombreMes}/${anio}`;
}

/**
 * Suma todas las rejas de un Vale es especifico
 * @param {Array} data - Arreglo con objetos {num_tabla, rejas}
 * @returns {number} - Total de rejas
 */
function sumarRejasVale(data) {
    return data.reduce((total, item) => total + item.rejas, 0);
}